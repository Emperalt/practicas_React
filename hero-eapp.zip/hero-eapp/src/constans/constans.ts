
export const heroes=
[
    {
      "_id": "623bb12b12979d2c2b04aba7",
      "title": "Black Widow",
      "body": "Trusted by some and feared by most, the Black Widow strives to make up for the bad she had done in the past by helping the world, even if that means getting her hands dirty in the process.",
      "image": "https://terrigen-cdn-dev.marvel.com/content/prod/1x/011blw_ons_crd_03.jpg",
      "category": "main",
      "idAuthor": "1",
      "createdAt": "Mon Apr 18 2022",
      "updatedAt": "Mon Apr 18 2022"
    },
    {
      "_id": "623bb12b12979d2c2b04abed",
      "title": "Hawkeye",
      "body": "An expert marksman and fighter, Clint Barton puts his talents to good use by working for S.H.I.E.L.D. as a special agent. The archer known as Hawkeye also boasts a strong moral compass that at times leads him astray from his direct orders.",
      "image": "https://terrigen-cdn-dev.marvel.com/content/prod/1x/018hcb_ons_crd_02.jpg",
      "category": "main",
      "idAuthor": "1",
      "createdAt": "2022-03-03T01:37:01.828Z",
      "updatedAt": "2022-03-03T01:37:01.828Z"
    },
    {
      "_id": "624db1646984eaac6378f00b",
      "title": "Doctor Strange",
      "body": "Once a highly successful, yet notably egotistical, surgeon, Doctor Stephen Strange endured a terrible accident that led him to evolve in ways he could have never foreseen.",
      "image": "https://terrigen-cdn-dev.marvel.com/content/prod/1x/009drs_ons_crd_02.jpg",
      "category": "main",
      "idAuthor": "1",
      "createdAt": "",
      "updatedAt": "",
      "__v": 0
    }
  ]