import { useEffect, useState } from 'react';
import './App.scss';
import { Personaje } from './interfaces/interface';
// import { heroes } from './constans/constans';



function App() {

  const h: Personaje[]= [];
  const [misHeroes,setMisHeroes]= useState(h)
  const [busqueda,setBusqueda]=useState("")
  const [nuevoHeroe,setNuevoHeroe]= useState(false)


 const busquedaInicial = ()=>{

  fetch(
    `http://bp-marvel-api.herokuapp.com/marvel-characters?idAuthor=19`
  )
    .then((response) => {
      return response.json();
    })
    .then((resultadoHeroes) => {
      setMisHeroes(resultadoHeroes);
    })
    .catch((error) => {
      console.log("Hubo un error" + error);
    });

 }


//  const eliminar =()=>{


//  }

  useEffect(()=> {
    if (busqueda.length ===0) {  
  
       busquedaInicial();
      } 

    })
  
    useEffect(()=> {
      if (busqueda.length > 1) {  
    
        console.log(busqueda)
        fetch(
          `http://bp-marvel-api.herokuapp.com/marvel-characters?idAuthor=19&title=${busqueda}`
        )
          .then((response) => {
            return response.json();
          })
          .then((resultadoHeroes) => {
            setMisHeroes(resultadoHeroes);
          })
          .catch((error) => {
            console.log("Hubo un error" + error);
          });
       } 

    },[busqueda])



  return (
   <div className='divApp'>
     <div className='divApp_divHeroe'>
        <div className='divApp_divHeroe_divTitulo'>
           Listado de Personajes
        </div>
        <div className='divApp_divHeroe_divControl'>
          <div className='divApp_divHeroe_divControl_divInput'>
             <img className='divApp_divHeroe_divControl_img_bt'
              src='https://cdn-icons-png.flaticon.com/512/107/107122.png'>
             </img> 
            <input 
              className='divApp_divHeroe_divControl_input'
              placeholder='Buscar'
              value={busqueda}
              onChange={(event)=>{setBusqueda(event.target.value)}}/>
            </div>                    
          <button 
             className='divApp_divHeroe_divControl_button'
             onClick={()=>setNuevoHeroe(true)}
             >
             <img className='divApp_divHeroe_divControl_img_bt'
              src='https://docs.vmware.com/es/VMware-NSX-Intelligence/3.2/user-guide/images/GUID-5004A6D0-4B28-485F-B629-21F9E5014AC1-low.png'>
             </img>  
            Nuevo
          </button>
        </div>
        
      {
        (misHeroes.length>1 && !nuevoHeroe )  &&
        misHeroes.map((heroe,index)=>{
          return(
            <div className='divApp_divHeroes'>
                <div>
                  <img
                    className='divApp_divHeroes_divImgHeroe'
                    src={heroe.image}>
                  </img>
                </div>
                <div className='divApp_divHeroes_div_nombreHeroe' >
                  {heroe.title}
                </div>
                <div className='divApp_divHeroes_divButton'> 
                  <button 
                      className='divApp_divHeroes_divButton_btn'
                      >
                      <img className='divApp_divHeroe_divControl_img_bt'
                        src='https://img.icons8.com/cotton/2x/000000/edit.png'>
                      </img>  
                      
                  </button>
                  <button 
                      className='divApp_divHeroes_divButton_btn'
                      >
                      <img className='divApp_divHeroe_divControl_img_bt'
                        src='https://ayudawp.com/wp-content/uploads/2018/04/borrar-plugins-wordpress.png'>
                      </img>  
                      
                  </button>
                </div>
              </div>            
           )
                  
          })
        }
        {
        (misHeroes.length===0 && !nuevoHeroe) &&
            <div className='divApp_divNoData'>No hubo Resultado!!</div>
          
        }
        {
         nuevoHeroe &&
          <div className='divAppdivNuevo'>
            <div className='divApp_divHeroe_divTitulo'>Nuevo Personaje</div>
            <div className='divAppdivNuevo_divImput'>
              Nombre:
              <input
                 placeholder='Nombre'  
                 className='divAppdivNuevo_divImput_input' type="text" />
            </div>
            <div className='divAppdivNuevo_divImput'>
              Descripción:
              <input  
                placeholder='Descripción'  
                className='divAppdivNuevo_divImput_input' type="text" />
            </div>
            <div className='divAppdivNuevo_divImput'>
              Imagen:
              <input  
                 placeholder='URL'  
                 className='divAppdivNuevo_divImput_input' type="text" />
            </div>

            <div className='divAppdivNuevodivButton'>
              <button 
              className='divApp_divHeroe_divControl_button'
              
              >
              <img className='divApp_divHeroe_divControl_img_bt'
                src='https://cdn.icon-icons.com/icons2/2066/PNG/512/save_icon_125167.png'>
              </img>  
              Guardar
            </button>
            <button 
              className='divApp_divHeroe_divControl_button'
              onClick={()=>setNuevoHeroe(false)}
              >
              <img className='divApp_divHeroe_divControl_img_bt'
                src='https://cdn-icons-png.flaticon.com/512/107/107258.png'>
              </img>  
              Cancelar
            </button>
            </div>
          </div>  
        }
        </div>
      

     </div>

    
   
  );

}

export default App;
